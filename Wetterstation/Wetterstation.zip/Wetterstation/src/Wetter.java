public class Wetter {

    public static void main(String[] args)
    {
	     Wetterstation weather = new Wetterstation();

	     weather.Wetter();
    }
}
